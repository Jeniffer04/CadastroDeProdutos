﻿using BLL;
using CadastroDeProdutos.Models;
using DLL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Diagnostics;

namespace CadastroDeProdutos.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult CadastroProdutos()
        {
            return View();
        }

        public IActionResult AuthenticCadastroProdutos(string nomeProduto, string preco, string marcaProduto, int quantidade, string descrição, string animal, string categorias, bool carro)
        {

            Produto prod = new Produto()
            {
                NomeProduto = nomeProduto,
                Preco = preco,
                MarcaProduto = marcaProduto,
                Quantidade = quantidade,
                Descricao = descrição,
                Animal = animal,
                Categoria = categorias,
                Carro = carro
            };
            Response res = ProdutoBAL.Insert(prod);

            if (res.Executed == true)
            {
                return RedirectToAction("CadastroProdutos", "Home");
            }
            else 
            {
                return RedirectToAction(res.ErrorMessage);

            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
