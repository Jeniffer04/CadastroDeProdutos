﻿using DLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public static class ProdutoBAL
    {
        public static Response Insert(Produto pro)
        {
            if (Checker.StringChecker(pro.NomeProduto, 50) && Checker.StringChecker(pro.MarcaProduto, 50) && Checker.StringChecker(pro.Categoria, 50) && Checker.StringChecker(pro.Animal, 50) && Checker.StringChecker(pro.Preco, 50) && Checker.IntChecker(pro.Quantidade) && Checker.StringChecker(pro.Descricao, 50))
            {
                return ProdutoDB.Insert(pro);
            }
            else
            {
                return new Response
                {
                    Executed = false,
                    ErrorMessage = "Erro ao inserir produto"
                };
            }
        }
    }
}
