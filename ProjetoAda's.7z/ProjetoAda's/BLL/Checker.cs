﻿using System;

namespace BLL
{
    public static class Checker
    {



        //esta função confere se a string é vazia e se esta no tamanho correto
        public static bool StringChecker(string value, int lenght)
        {
            return (!string.IsNullOrEmpty(value) && value.Length <= lenght);

        }
        //esta função confere se o int é vazio (precisamo conferir se o input feito pelo usuario é alguma letra e não um inteiro)
        public static bool IntChecker(int value)
        {
            return (!string.IsNullOrEmpty(value.ToString()));

        }
        //esta função confere se o double (preço)inserido pelo usuario esta vazio (também precisa ser conferido a letra, fazer um try catch?)

        public static bool DoubleChecker(double value)
        {
            return (!string.IsNullOrEmpty(value.ToString()));

        }



    }
}
