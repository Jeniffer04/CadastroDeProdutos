﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL
{
    public class ProdutoCarrinho
    {
        //fk_Cliente

        public int IdCliente { get; set; }
    }
}
