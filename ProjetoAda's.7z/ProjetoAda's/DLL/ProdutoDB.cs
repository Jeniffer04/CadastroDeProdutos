﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL
{
    public class ProdutoDB
    {
        //objeto produto

        Produto pro = new Produto();

        //esta função esta conferindo o estado da conexão, caso ela tenha sido aberta e não fechada
        public static Response ExceptionGet(Exception error)
        {
            if (StringConnection.Connection.State == System.Data.ConnectionState.Open)
            {
                StringConnection.Connection.Close();

            }
            return new Response
            {
                Executed = false,
                ErrorMessage = error.Message,
                Exception = error

            };
        }

        //esta função esta inserindo os produtos no banco de dados
        public static Response Insert(Produto pro)
        {
            //pro = new Produto();

            //verificar ID
            string insert = $"INSERT into dbo.Produto (NomeProduto, MarcaProduto, Categoria, Animal, Preco, Quantidade, Descricao, Carro) values" +
                $"('{pro.NomeProduto}','{pro.MarcaProduto}','{pro.Categoria}','{pro.Animal}','{pro.Preco}',{pro.Quantidade}, '{pro.Descricao}',{Convert.ToInt32(pro.Carro)})";
            SqlCommand cmd = new SqlCommand(insert, StringConnection.Connection);
            try
            {
                StringConnection.Connection.Open();
                cmd.ExecuteNonQuery();
                StringConnection.Connection.Close();
                return new Response
                {
                    Executed = true
                };

            }
            catch (Exception error)
            {
                return ExceptionGet(error);
            }            
        }
    }
}
