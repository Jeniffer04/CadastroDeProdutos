﻿using System.Data.SqlClient;

namespace DLL
{
    public static class StringConnection
    {
        //alterar a conexão para que a conexão usada seja a conexão do adas pet
        public static SqlConnection Connection { get; } = new SqlConnection("Data Source=BUE205D16;Initial Catalog=BDTurmaVesp;Persist Security Info=True;User ID=guest01;Password=@Senac2021");
    }
}
