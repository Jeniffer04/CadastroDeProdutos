﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL
{
    public class CarrinhoDB
    {
        List<ProdutoCarrinho> Carrinho = new List<ProdutoCarrinho>();
    }
}
