﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL
{
    public class Produto
    {
        public int idProduto { get; set; }
        public string NomeProduto { get; set; }
        public string MarcaProduto { get; set; }
        public string Categoria { get; set; }
        public string Animal { get; set; }
        public string Preco { get; set; }
        public int Quantidade { get; set; }
        public string Descricao { get; set; }
        public bool Carro { get; set; }
    }
}
